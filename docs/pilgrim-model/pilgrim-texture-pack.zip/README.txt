Pilgrim shared UV atlas: 512x512.
Use albedo as colour and emission as glow.
The SVG and transparent PNG are actual UV edges.
Repeated parts share patches. Do not resize/move atlas regions independently.
Labels are on the guide only.
